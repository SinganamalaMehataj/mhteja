package com.lti.service;

import com.lti.model.Institute;
import com.lti.model.Student;

public interface InstituteService {
	public boolean addInstitute(Institute institute);
	public boolean addStudent(Student student);
}
