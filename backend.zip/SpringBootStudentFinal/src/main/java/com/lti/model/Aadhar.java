package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="")
public class Aadhar {

	@Id
	@Column(name="aadhar_no")
	private int aadharNo;
	@Column(name="name")
	private String name;
	@Column(name="mother_name")
	private String MotherName;
	@Column(name="date_of_birth")
	private String dob;
	@Column(name="gender")
	private String gender;
	@Column(name="door_no")
	private String doorNo;
	@Column(name="street")
	private String street;
	private String city;
	private String district;
	private String state;
	private int pincode;
	private int mobileNo;
	public int getAadharNo() {
		return aadharNo;
	}
	public void setAadharNo(int aadharNo) {
		this.aadharNo = aadharNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMotherName() {
		return MotherName;
	}
	public void setMotherName(String motherName) {
		MotherName = motherName;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(String doorNo) {
		this.doorNo = doorNo;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getPincode() {
		return pincode;
	}
	public void setPincode(int pincode) {
		this.pincode = pincode;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Aadhar(int aadharNo, String name, String motherName, String dob, String gender, String doorNo, String street,
			String city, String district, String state, int pincode, int mobileNo) {
		super();
		this.aadharNo = aadharNo;
		this.name = name;
		MotherName = motherName;
		this.dob = dob;
		this.gender = gender;
		this.doorNo = doorNo;
		this.street = street;
		this.city = city;
		this.district = district;
		this.state = state;
		this.pincode = pincode;
		this.mobileNo = mobileNo;
	}
	public Aadhar() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Aadhar [aadharNo=" + aadharNo + ", name=" + name + ", MotherName=" + MotherName + ", dob=" + dob
				+ ", gender=" + gender + ", doorNo=" + doorNo + ", street=" + street + ", city=" + city + ", district="
				+ district + ", state=" + state + ", pincode=" + pincode + ", mobileNo=" + mobileNo + "]";
	}
	
	
}
